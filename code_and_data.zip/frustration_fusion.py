import pandas as pd
import numpy as np
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import sklearn.metrics as skm
import os

# Parent directory of all groups
parent_dir = os.getcwd()
data_dir = os.path.join(parent_dir,"Processed_Data_frustration")
w_dim = 300

df_cols = ["t_win", "t_dim", "strat", "tsai_acc", "xg_acc", "fused_acc", "std", "fused_pre", "fused_rec", "fused_f1"]
res_rows = []

def convert_to_binary(XY_df) -> pd.DataFrame:
    """
    Convert input dataframe to binary classification by dropping slightly annotations
    :param XY_df: input dataframe with all emotion annoations
    :return: Dataframe with slightly values dropped and combined very and extremely
    """
    XY_df = XY_df[XY_df["Rating"] != 1]
    for idx,row in XY_df.iterrows():
        if row["Rating"] >= 2:
             XY_df.loc[idx, "Rating"] = 1
    return XY_df

results_df = pd.read_csv(os.path.join(parent_dir,"tsai_frustration_results.tsv"), sep="\t")

for t_w in [1500,2000,2500,3000,3500,4000,4500,5000]:
    # Load the data
    word_X_df = pd.read_csv(os.path.join(data_dir,f"X_{t_w}milli_word_embeddings.tsv"), sep='\t')
    word_Y_df = pd.read_csv(os.path.join(data_dir,f"Y_{t_w}milli_word_embeddings.tsv"), sep='\t')

    # Define test data
    test_groups = ["31C", "22N", "25C"]
    test_df = pd.concat([word_X_df,word_Y_df],axis=1)
    test_df = convert_to_binary(test_df)
    test_df = test_df[test_df["Group"].isin(test_groups)]
    test_X = test_df.iloc[:, 0:(w_dim)].to_numpy()
    test_y = test_df["Rating"].to_numpy()

    # Define train data
    train_df = pd.concat([word_X_df,word_Y_df],axis=1)
    train_df = convert_to_binary(train_df)
    train_df = train_df[~train_df["Group"].isin(test_groups)]
    train_X = train_df.iloc[:, 0:(w_dim)].to_numpy()
    train_y = train_df["Rating"].to_numpy()

    # Run experiments
    for t_d in [5, 10, 15, 20]:
        for d_s in [0]:
            xg_acc = []
            curr_acc = []
            curr_pre = []
            curr_rec = []
            curr_f1 = []
            for seed_state in range(3):
                    # Split the data
                    X_train, X_test, y_train, y_test = train_test_split(train_X, train_y, test_size=0.2, random_state=seed_state)

                    # Create an instance of the XGBoost classifier
                    model = XGBClassifier()

                    # Set the hyperparameters
                    model.set_params(
                        # learning_rate=0.1,
                        # n_estimators=100,
                        # max_depth=10,
                        seed=seed_state,
                        objective='binary:logistic'
                    )

                    # Fit the model
                    model.fit(X_train, y_train)

                    # Predict on the test set
                    y_probas_xg = model.predict_proba(test_X)
                    y_pred_xg = model.predict(test_X)

                    # Get the tsai probabilities
                    y_pred_tsai = eval(results_df[(results_df["t_win"] == t_w) & (results_df["t_dim"] == t_d) & (results_df["strat"] == d_s)]["probas"].iloc[0])
                    
                    # Average the xg_boost probabilities with the tsai results
                    fused_preds = np.divide(np.add(y_pred_tsai, y_probas_xg),2)
                    fused_preds = [0 if p[0] > p[1] else 1 for p in fused_preds]
                    
                    # Store predictions for output
                    xg_acc += [skm.accuracy_score(test_y, y_pred_xg)]
                    curr_acc += [skm.accuracy_score(test_y, fused_preds)]
                    curr_pre += [skm.precision_score(test_y, fused_preds)]
                    curr_rec += [skm.recall_score(test_y, fused_preds)]
                    curr_f1 += [skm.f1_score(test_y, fused_preds)]

            tsai_acc = results_df[(results_df["t_win"] == t_w) & (results_df["t_dim"] == t_d) & (results_df["strat"] == d_s)]["acc"].iloc[0]
            xg_acc = np.average(xg_acc)
            std = np.std(curr_acc)
            curr_acc = np.average(curr_acc)
            curr_pre = np.average(curr_pre)
            curr_rec = np.average(curr_rec)
            curr_f1 = np.average(curr_f1)
            res_rows.append([t_w,t_d,d_s,tsai_acc,xg_acc,curr_acc,std,curr_pre,curr_rec,curr_f1])
    
out_df = pd.DataFrame(np.array(res_rows), columns=df_cols)
out_df.to_csv("fused_frustration_results.tsv",index=False,sep="\t")