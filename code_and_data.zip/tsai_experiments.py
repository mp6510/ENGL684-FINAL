# Modeling and machine learning
from tsai.all import *
import sklearn.metrics as skm

# Standard libraries
import pandas as pd
import numpy as np
import os

def transform_timeseries(X, t_dim) -> np.array:
    """
    Convert input X to a 3D time series array for tsai
    :param X: numpy array of the 2D time series
    :param t_dim: int of the time steps
    :return: 3D numpy array of shape (instances, modalities, time steps)
    """
    X_3d = []
    for row in X:
        X_3d.append(np.array(np.array_split(row,t_dim)).transpose())
    return np.array(X_3d)

def convert_to_binary(XY_df) -> pd.DataFrame:
    """
    Convert input dataframe to binary classification by dropping slightly annotations
    :param XY_df: input dataframe with all emotion annoations
    :return: Dataframe with slightly values dropped and combined very and extremely
    """
    XY_df = XY_df[XY_df["Rating"] != 1]
    for idx,row in XY_df.iterrows():
        if row["Rating"] >= 2:
             XY_df.loc[idx, "Rating"] = 1
    return XY_df


df_cols = ["t_win", "t_dim", "strat", "acc", "prec", "recall", "f1", "probas"]
res_rows = []

for t_w in [1500,2000,2500,3000,3500,4000,4500,5000]:
    for t_d in [5, 10, 15, 20]:
        for d_s in [0]:
            # Hyperparameters
            time_window = t_w # Milliseconds
            t_dim = t_d # Number of timesteps per modality
            m_dim = 12 # Number of modalities
            binary_class = True
            include_og = False

            # Parent directory of all groups
            parent_dir = os.getcwd()
            data_dir = os.path.join(parent_dir,"Processed_Data_frustration")

            # Read in baseline data
            X0_df = pd.read_csv(os.path.join(data_dir,f"X_{time_window}milli_{t_dim}dim_0strat.tsv"), sep='\t')
            Y0_df = pd.read_csv(os.path.join(data_dir,f"Y_{time_window}milli_{t_dim}dim_0strat.tsv"), sep='\t')
            X0_df = X0_df.fillna(0)
            Y0_df = Y0_df.fillna(0)

            # Define test set groups
            test_groups = ["31C", "22N", "25C"]
            test_df = pd.concat([X0_df,Y0_df],axis=1)
            if binary_class:
                test_df = convert_to_binary(test_df)
            test_df = test_df[test_df["Group"].isin(test_groups)]
            test_X = test_df.iloc[:, 0:(t_dim*m_dim)].to_numpy()
            test_X = transform_timeseries(test_X, t_dim)
            test_y = test_df["Rating"].to_numpy()

            # Read in dataset for specific time window and dimension
            X_df = pd.read_csv(os.path.join(data_dir,f"X_{time_window}milli_{t_dim}dim_{d_s}strat.tsv"), sep='\t')
            Y_df = pd.read_csv(os.path.join(data_dir,f"Y_{time_window}milli_{t_dim}dim_{d_s}strat.tsv"), sep='\t')
            X_df = X_df.fillna(0)
            Y_df = Y_df.fillna(0)

            # Add in OG dataset
            if include_og:
                X_df = pd.concat([X_df,X0_df.iloc[:, 0:(t_dim*m_dim)]], axis=0, ignore_index = True)
                Y_df = pd.concat([Y_df,Y0_df], axis=0, ignore_index = True)
            
            # Define development data by removing test data from training data
            train_df = pd.concat([X_df,Y_df],axis=1)
            if binary_class:
                train_df = convert_to_binary(train_df)
            train_df = train_df[~train_df["Group"].isin(test_groups)]
            X_df = train_df.iloc[:, 0:(t_dim*m_dim)]
            Y_df = train_df["Rating"]
            train_X = X_df.to_numpy()
            train_X = transform_timeseries(train_X, t_dim)
            train_y = Y_df.to_numpy()

            # Get train-valid split indicies, doing a 80/20
            dev_split_i = int(np.ceil(train_X.shape[0]*0.8))
            splits = ([train_i for train_i in range(0,dev_split_i)],[train_i for train_i in range(dev_split_i,train_X.shape[0])])

            # Build DataLoader for creating batches of data
            tfms  = [None, [Categorize()]]
            dsets = TSDatasets(train_X, train_y, tfms=tfms, splits=splits, inplace=True)
            dls = TSDataLoaders.from_dsets(dsets.train, dsets.valid, bs=[64, 128], batch_tfms=[TSStandardize()], num_workers=0)

            # Build learner model
            model = InceptionTime(dls.vars, dls.c)
            learn = Learner(dls, model, metrics=accuracy)
            learn.save('stage0')

            # LR find
            learn.load('stage0')
            # learn.lr_find()

            # Train the model
            learn.fit_one_cycle(25, lr_max=1e-3)
            learn.save('stage1')
            learn.recorder.plot_metrics()

            # Inference on the test data set
            valid_dl = dls.valid
            test_ds = valid_dl.dataset.add_test(test_X, test_y)
            test_dl = valid_dl.new(test_ds)
            test_probas, test_targets, test_preds = learn.get_preds(dl=test_dl, with_decoded=True, save_preds=None, save_targs=None)
            print(f'accuracy: {skm.accuracy_score(test_targets, test_preds):10.6f}')

out_df = pd.DataFrame(np.array(res_rows), columns=df_cols)
print(out_df)
out_df = pd.DataFrame(np.array(res_rows), columns=df_cols)
out_df.to_csv("tsai_frustration_results.tsv",index=False,sep="\t")