Data shape: (297, 240)
——— Modality Labels ———
m1 = Brow Furrow
m2 = Chin Raise
m3 = Lip Corner Depressor
m4 = Lid Tighten
m5 = Gaze Velocity
m6 = Fixation Duration
m7 = Fixation Dispersion
m8 = Saccade Duration
m9 = Saccade Peak Velocity
m10 = GSR Conductance CAL
m11 = Intensity_dB
m12 = F0_Hz

——— Hyperparameters ———
time_window (milliseconds) = 5000
t_dim = 20
dropping_strat = 0

——— Logging Warnings ———
Missing ['F0_Hz'] for 18N at row 13 — Padding with NaNs !! 
Missing ['F0_Hz'] for 20N at row 0 — Padding with NaNs !! 
Missing ['F0_Hz'] for 21C at row 0 — Padding with NaNs !! 
Missing ['Intensity_dB'] for 26N at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 26N at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 0 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 1 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 3 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 5 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 7 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 10 — Padding with NaNs !! 
Missing ['Intensity_dB'] for 28N at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 30N at row 1 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 5 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 10 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 18 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 32 — Padding with NaNs !! 
Missing ['F0_Hz'] for 32N at row 1 — Padding with NaNs !! 
Missing ['F0_Hz'] for 34N at row 4 — Padding with NaNs !! 
Missing ['F0_Hz'] for 35C at row 0 — Padding with NaNs !! 
Missing ['F0_Hz'] for 38N at row 8 — Padding with NaNs !! 
Missing ['Intensity_dB'] for 38N at row 12 — Padding with NaNs !! 
Missing ['F0_Hz'] for 38N at row 12 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 4 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 5 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 15 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 17 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 18 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 21 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 22 — Padding with NaNs !! 
Missing ['F0_Hz'] for 40N at row 5 — Padding with NaNs !! 
