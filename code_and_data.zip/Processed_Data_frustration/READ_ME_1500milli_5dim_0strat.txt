Data shape: (297, 60)
——— Modality Labels ———
m1 = Brow Furrow
m2 = Chin Raise
m3 = Lip Corner Depressor
m4 = Lid Tighten
m5 = Gaze Velocity
m6 = Fixation Duration
m7 = Fixation Dispersion
m8 = Saccade Duration
m9 = Saccade Peak Velocity
m10 = GSR Conductance CAL
m11 = Intensity_dB
m12 = F0_Hz

——— Hyperparameters ———
time_window (milliseconds) = 1500
t_dim = 5
dropping_strat = 0

——— Logging Warnings ———
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 18N at row 10 — Padding with NaNs !! 
Missing ['F0_Hz'] for 18N at row 13 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 19C at row 3 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 19C at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 19C at row 24 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 19C at row 25 — Padding with NaNs !! 
Missing ['F0_Hz'] for 19C at row 25 — Padding with NaNs !! 
Missing ['F0_Hz'] for 20N at row 0 — Padding with NaNs !! 
Missing ['F0_Hz'] for 21C at row 0 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 21C at row 2 — Padding with NaNs !! 
Missing ['F0_Hz'] for 21C at row 2 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 21C at row 3 — Padding with NaNs !! 
Missing ['F0_Hz'] for 22N at row 5 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 22N at row 6 — Padding with NaNs !! 
Missing ['F0_Hz'] for 22N at row 7 — Padding with NaNs !! 
Missing ['Gaze Velocity'] for 22N at row 9 — Padding with NaNs !! 
Missing ['Fixation Duration', 'Fixation Dispersion'] for 22N at row 9 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 22N at row 9 — Padding with NaNs !! 
Missing ['F0_Hz'] for 22N at row 14 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 22N at row 15 — Padding with NaNs !! 
Missing ['F0_Hz'] for 22N at row 15 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 22N at row 20 — Padding with NaNs !! 
Missing ['F0_Hz'] for 22N at row 22 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 22N at row 23 — Padding with NaNs !! 
Missing ['F0_Hz'] for 23C at row 1 — Padding with NaNs !! 
Missing ['F0_Hz'] for 24N at row 5 — Padding with NaNs !! 
Missing ['F0_Hz'] for 24N at row 11 — Padding with NaNs !! 
Missing ['F0_Hz'] for 26N at row 8 — Padding with NaNs !! 
Missing ['F0_Hz'] for 26N at row 15 — Padding with NaNs !! 
Missing ['Intensity_dB'] for 26N at row 18 — Padding with NaNs !! 
Missing ['F0_Hz'] for 26N at row 18 — Padding with NaNs !! 
Missing ['Intensity_dB'] for 26N at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 26N at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 0 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 1 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 3 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 4 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 5 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 6 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 7 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 8 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 27C at row 9 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 27C at row 14 — Padding with NaNs !! 
Missing ['F0_Hz'] for 27C at row 14 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 1 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 4 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 6 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 7 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 10 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 11 — Padding with NaNs !! 
Missing ['Gaze Velocity'] for 28N at row 14 — Padding with NaNs !! 
Missing ['Fixation Duration', 'Fixation Dispersion'] for 28N at row 14 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 28N at row 14 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 16 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 28N at row 18 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 18 — Padding with NaNs !! 
Missing ['Intensity_dB'] for 28N at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 28N at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 29C at row 2 — Padding with NaNs !! 
Missing ['F0_Hz'] for 29C at row 3 — Padding with NaNs !! 
Missing ['F0_Hz'] for 30N at row 1 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 31C at row 2 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 5 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 10 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 12 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 31C at row 13 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 13 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 18 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 20 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 31 — Padding with NaNs !! 
Missing ['Intensity_dB'] for 31C at row 32 — Padding with NaNs !! 
Missing ['F0_Hz'] for 31C at row 32 — Padding with NaNs !! 
Missing ['F0_Hz'] for 32N at row 1 — Padding with NaNs !! 
Missing ['F0_Hz'] for 33C at row 2 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 33C at row 7 — Padding with NaNs !! 
Missing ['F0_Hz'] for 33C at row 10 — Padding with NaNs !! 
Missing ['Intensity_dB'] for 33C at row 11 — Padding with NaNs !! 
Missing ['F0_Hz'] for 33C at row 11 — Padding with NaNs !! 
Missing ['F0_Hz'] for 34N at row 4 — Padding with NaNs !! 
Missing ['F0_Hz'] for 34N at row 9 — Padding with NaNs !! 
Missing ['F0_Hz'] for 34N at row 10 — Padding with NaNs !! 
Missing ['F0_Hz'] for 35C at row 0 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 35C at row 7 — Padding with NaNs !! 
Missing ['F0_Hz'] for 35C at row 8 — Padding with NaNs !! 
Missing ['F0_Hz'] for 36N at row 0 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 36N at row 7 — Padding with NaNs !! 
Missing ['F0_Hz'] for 36N at row 10 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 36N at row 11 — Padding with NaNs !! 
Missing ['F0_Hz'] for 36N at row 11 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 36N at row 12 — Padding with NaNs !! 
Missing ['F0_Hz'] for 37C at row 0 — Padding with NaNs !! 
Missing ['F0_Hz'] for 38N at row 5 — Padding with NaNs !! 
Missing ['F0_Hz'] for 38N at row 8 — Padding with NaNs !! 
Missing ['Intensity_dB'] for 38N at row 12 — Padding with NaNs !! 
Missing ['F0_Hz'] for 38N at row 12 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 39C at row 1 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 3 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 4 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 39C at row 5 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 5 — Padding with NaNs !! 
Missing ['Gaze Velocity'] for 39C at row 8 — Padding with NaNs !! 
Missing ['Fixation Duration', 'Fixation Dispersion'] for 39C at row 8 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 39C at row 8 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 11 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 13 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 14 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 15 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 16 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 17 — Padding with NaNs !! 
Missing ['Gaze Velocity'] for 39C at row 18 — Padding with NaNs !! 
Missing ['Fixation Duration', 'Fixation Dispersion'] for 39C at row 18 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 39C at row 18 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 18 — Padding with NaNs !! 
Missing ['Gaze Velocity'] for 39C at row 19 — Padding with NaNs !! 
Missing ['Fixation Duration', 'Fixation Dispersion'] for 39C at row 19 — Padding with NaNs !! 
Missing ['Saccade Duration', 'Saccade Peak Velocity'] for 39C at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 19 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 21 — Padding with NaNs !! 
Missing ['F0_Hz'] for 39C at row 22 — Padding with NaNs !! 
Missing ['F0_Hz'] for 40N at row 1 — Padding with NaNs !! 
Missing ['F0_Hz'] for 40N at row 2 — Padding with NaNs !! 
Missing ['F0_Hz'] for 40N at row 5 — Padding with NaNs !! 
